
/*
Name : Nishanth G N
Date : 12/03/2024
Description : Steganography
Sample Execution :
1. For Encoding
$ ./a.out -e beautiful.bmp secret.txt stego.bmp
Selected Encoding
Read and validate argument is success
Opened all the required files successfully
Started encoding....
width = 1024
height = 768
Check capacity is successful
Successfully copied the header
Encoding magic string is successful
Encoded secret file extension size successfully
Encoding secret file extension is successful
Encoding secret file size is success
Successfully encoded secret data
Copied remaining image data successfully
Encoding is successful


2. For Decoding

Selected Decoding
Read and validate decode argument is successful
Decoding procedure started
Opened required files is successfully
Successfully decoded magic string
Succesfully decoded file extension size
Succesfully decoded Secret File Extension
Successfully decoded secret file size
Successfully Decoded secret file data
 Decoding is successful
*/

#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc, char *argv[])
{

    //check operation type
    if(check_operation_type(argv) == e_encode)
    
        {
	EncodeInfo encInfo;
	printf("Selected Encoding\n");
	//validate arguments for encoding

	if(read_and_validate_encode_args(argv, &encInfo) == e_success)
	{
	    printf("Read and validate argument is success\n");
	    if(do_encoding(&encInfo) == e_success)
	    {
		printf("Encoding is successful\n");
	    }
	    else
	    {
		printf("Encoding is not done... unsuccessful\n");
	    }
	}
	else
	{
	    printf("Failure: While Read and validate argument\n");
	}

    }
    else if(check_operation_type(argv) == e_decode)
    {
	DecodeInfo decInfo;
            printf("Selected Decoding\n");
            if (read_and_validate_decode_args(argv, &decInfo) == d_success)
            {
                printf("Read and validate decode argument is successful\n");
            printf("Decoding procedure started\n");
                if (do_decoding(&decInfo) == d_success)
                {
                    printf(" Decoding is successful\n");
                }
                else
                {
                    printf("Failed decoding the data\n");
		    printf("Decoding: ./a.out -d stego.bmp output.txt\n");
                    return d_failure;
                }
            }
    }
    else
    {
	printf("Invalid Option\nUsage:\n");
	printf("Encoding: ./a.out -e beautiful.bmp secret.txt stego.bmp\n");
	printf("Decoding: ./a.out -d stego.bmp output.txt\n");
    }
    return 0;
}
OperationType check_operation_type(char *argv[])
{
    if(strcmp(argv[1], "-e") == 0)
    {
	return e_encode;
    }
    else if(strcmp(argv[1], "-d") == 0)
    {
	return e_decode;
    }
    else
    {
	return e_unsupported;

    }
}
